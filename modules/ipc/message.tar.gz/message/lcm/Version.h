#ifndef VERSION_H_
#define VERSION_H_

const int nVersionLayer1=3;
const int nVersionLayer2=5;
const int nVersionLayer3=2;

const int nReleaseTimeYear = 2016;
const int nReleaseTimeMonth = 12;
const int nReleaseTimeDay = 22;

#endif
